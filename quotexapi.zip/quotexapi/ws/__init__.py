"""Module for Quotex API websocket."""
