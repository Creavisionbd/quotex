import collections
from quotexapi.ws.chanels.base import Base
from quotexapi.constants import constants as OP_code
from quotexapi.global_value import global_value
import json

class loadHistoryPeriod(Base):
    pass
  
class changeSymbol(Base):
    pass
  
class unsubfor(Base):
    pass
