
from quotexapi.ws.chanels.base import Base
from quotexapi.constants import constants as OP_code
from quotexapi.global_value import global_value
import json

class buy_binary(Base):
    pass

class cancelOrder(Base):
    pass
