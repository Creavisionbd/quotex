from quotexapi.ws.chanels.base import Base
import json

class auth_mode(Base):
    
    def __call__(self, account_mode):
        pass
