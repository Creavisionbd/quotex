from quotexapi.ws.chanels.base import Base
class Ping_To_Server(Base):
    pass



class Ping_To_Server_2(Base):
    pass
